// Tarih formatlama fonksiyonları
export const formatDate = (date, format = 'DD/MM/YYYY') => {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  
  return format
    .replace('DD', day)
    .replace('MM', month)
    .replace('YYYY', year);
};

export const formatTime = (date) => {
  const d = new Date(date);
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  
  return `${hours}:${minutes}`;
};

// Tarih hesaplama fonksiyonları
export const addDays = (date, days) => {
  const result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
};

export const subtractDays = (date, days) => {
  const result = new Date(date);
  result.setDate(result.getDate() - days);
  return result;
};

export const getDaysBetween = (startDate, endDate) => {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const diffTime = Math.abs(end - start);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

// Validasyon fonksiyonları
export const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const isValidDate = (date) => {
  const d = new Date(date);
  return d instanceof Date && !isNaN(d);
};

// Array işlemleri
export const groupBy = (array, key) => {
  return array.reduce((result, item) => {
    const group = item[key];
    if (!result[group]) {
      result[group] = [];
    }
    result[group].push(item);
    return result;
  }, {});
};

export const sortByDate = (array, key = 'date', ascending = true) => {
  return [...array].sort((a, b) => {
    const dateA = new Date(a[key]);
    const dateB = new Date(b[key]);
    return ascending ? dateA - dateB : dateB - dateA;
  });
};

// Storage yardımcıları
export const storageKeys = {
  USER_DATA: 'user_data',
  CYCLE_DATA: 'cycle_data',
  SETTINGS: 'settings',
  REMINDERS: 'reminders',
};

// Hesaplama fonksiyonları
export const calculateAverageCycle = (cycles) => {
  if (!cycles || cycles.length < 2) return null;
  
  const intervals = [];
  for (let i = 1; i < cycles.length; i++) {
    const days = getDaysBetween(cycles[i - 1].startDate, cycles[i].startDate);
    intervals.push(days);
  }
  
  const average = intervals.reduce((sum, interval) => sum + interval, 0) / intervals.length;
  return Math.round(average);
};

export const calculateNextPeriod = (lastPeriodDate, averageCycle) => {
  if (!lastPeriodDate || !averageCycle) return null;
  return addDays(lastPeriodDate, averageCycle);
}; 