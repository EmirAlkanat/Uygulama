import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SIZES } from '../../constants';
import { globalStyles } from '../../styles/globalStyles';

const privacyOptions = [
  {
    id: 1,
    text: [
      'Adettim işlemlerinin sağlanması amacıyla kişisel sağlık bilgilerimin işlenmesini kabul ediyorum. ',
      'Gizlilik Politikamızda',
      ' bilgi edinebilirsiniz.'
    ],
  },
  {
    id: 2,
    text: [
      '','Gizlilik Politikasını',' ve ','Kullanım Şartlarını',' kabul ediyorum.'
    ],
  },
  {
    id: 3,
    text: [
      "Adettim'in uygulama kullanım etkinliğimi izlemesine izin vermeyi ve AppsFlyer ve entegre ortaklarının yaş grubum, abonelik durumum, uygulama başlatılma durumu ve ",
      'Gizlilik Politikası',
      "'nda açıklandığı gibi teknik tanımlayıcılarım hakkında bilgi alabileceğini kabul ediyorum. Bu, Adettim'in reklam kampanyalarını iyileştirmesine yardımcı olur."
    ],
  },
];

const PrivacyScreen = ({ navigation }) => {
  const [checked, setChecked] = useState([false, false, false]);

  const allChecked = checked.every(Boolean);

  const handleCheck = (idx) => {
    const newChecked = [...checked];
    newChecked[idx] = !newChecked[idx];
    setChecked(newChecked);
  };

  const handleCheckAll = () => {
    setChecked([true, true, true]);
  };

  return (
    <SafeAreaView style={globalStyles.safeArea}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.headerImageContainer}>
          {/* Buraya örnek bir kalp/dişli görseli eklenebilir */}
          <Image source={require('../../../assets/main_logo.png')} style={styles.headerImage} resizeMode="contain" />
        </View>
        <Text style={styles.title}>Önce gizlilik</Text>
        <View style={styles.optionsContainer}>
          {privacyOptions.map((option, idx) => (
            <View key={option.id} style={styles.optionRow}>
              <TouchableOpacity
                style={styles.checkboxTouchable}
                activeOpacity={0.7}
                onPress={() => handleCheck(idx)}
              >
                <View style={[styles.checkbox, checked[idx] && styles.checkboxChecked]}>
                  {checked[idx] && <View style={styles.checkboxInner} />}
                </View>
              </TouchableOpacity>
              <View style={styles.optionTextRow}>
                <Text style={styles.optionText}>
                  {option.text.map((part, i) =>
                    (part.includes('Gizlilik') || part.includes('Kullanım')) ? (
                      <Text key={i} style={styles.link}>{part}</Text>
                    ) : (
                      <Text key={i}>{part.replace('*', '')}</Text>
                    )
                  )}
                </Text>
              </View>
            </View>
          ))}
        </View>
        <TouchableOpacity onPress={handleCheckAll} style={styles.acceptAllBtn} activeOpacity={0.8}>
          <Text style={styles.acceptAllText}>Tümünü kabul et</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.nextBtn, !allChecked && styles.nextBtnDisabled]}
          disabled={!allChecked}
          onPress={() => navigation.navigate('Nickname')}
        >
          <Text style={styles.nextBtnText}>İleri</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: SIZES.spacing.lg,
    backgroundColor: COLORS.background,
  },
  headerImageContainer: {
    alignItems: 'center',
    marginBottom: SIZES.spacing.lg,
  },
  headerImage: {
    width: 120,
    height: 120,
  },
  title: {
    fontSize: SIZES['2xl'],
    fontWeight: 'bold',
    color: COLORS.text.primary,
    textAlign: 'center',
    marginBottom: SIZES.spacing.lg,
  },
  optionsContainer: {
    marginBottom: SIZES.spacing.lg,
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: SIZES.spacing.base,
  },
  checkboxTouchable: {
    marginTop: 2,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: COLORS.gray[400],
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: SIZES.spacing.base,
    backgroundColor: COLORS.white,
  },
  checkboxChecked: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primary,
  },
  checkboxInner: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: COLORS.white,
  },
  optionTextRow: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
  },
  optionText: {
    fontSize: SIZES.base,
    color: COLORS.text.primary,
    flex: 1,
    flexWrap: 'wrap',
    textAlignVertical: 'center',
  },
  link: {
    color: COLORS.primary,
    textDecorationLine: 'underline',
  },
  acceptAllBtn: {
    alignSelf: 'center',
    marginBottom: SIZES.spacing.base,
  },
  acceptAllText: {
    color: COLORS.primary,
    fontWeight: 'bold',
    fontSize: SIZES.base,
  },
  nextBtn: {
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radius.full,
    paddingVertical: SIZES.spacing.base,
    alignItems: 'center',
    marginBottom: SIZES.spacing.lg,
  },
  nextBtnDisabled: {
    backgroundColor: COLORS.gray[300],
  },
  nextBtnText: {
    color: COLORS.white,
    fontWeight: 'bold',
    fontSize: SIZES.lg,
  },
});

export default PrivacyScreen; 