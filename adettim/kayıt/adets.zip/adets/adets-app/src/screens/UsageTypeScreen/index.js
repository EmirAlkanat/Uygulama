import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SIZES } from '../../constants';

const UsageTypeScreen = ({ navigation }) => {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.logoContainer}>
          <Image source={require('../../../assets/main_logo.png')} style={styles.logo} resizeMode="contain" />
        </View>
        <Text style={styles.title}>Adettim'i kendiniz için mi kullanıyorsunuz?</Text>
        <TouchableOpacity style={styles.optionBtn} onPress={() => navigation.navigate('Goal')}>
          <Text style={styles.optionText}>Evet</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.optionBtn} onPress={() => {/* Partner kodu seçildiğinde */}}>
          <Text style={styles.optionText}>Hayır, partner kodum var</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: SIZES.spacing.lg,
  },
  title: {
    fontSize: SIZES['2xl'],
    fontWeight: 'bold',
    color: COLORS.text.primary,
    textAlign: 'center',
    marginBottom: SIZES.spacing['2xl'],
  },
  optionBtn: {
    width: '100%',
    backgroundColor: COLORS.primary,
    borderRadius: 32,
    paddingVertical: SIZES.spacing.base,
    paddingHorizontal: SIZES.spacing.base,
    marginBottom: SIZES.spacing.lg,
    alignItems: 'center',
  },
  optionText: {
    fontSize: SIZES.base,
    color: COLORS.white,
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: 32,
    marginBottom: 16,
  },
  logo: {
    width: 100,
    height: 100,
  },
});

export default UsageTypeScreen; 