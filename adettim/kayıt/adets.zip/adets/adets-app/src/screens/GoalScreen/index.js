import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SIZES } from '../../constants';

const goals = [
  {
    id: 1,
    label: 'Reglimi takip etmek',
    image: null, // require('../../../assets/calendar.png') gibi eklenebilir
  },
  {
    id: 2,
    label: 'Hamile kalmaya çalışmak',
    image: null, // require('../../../assets/pregnancy_test.png') gibi eklenebilir
  },
  {
    id: 3,
    label: 'Hamileliğimi takip etmek',
    image: null, // require('../../../assets/baby.png') gibi eklenebilir
  },
  {
    id: 4,
    label: 'Partneri takip et',
    image: null, // require('../../../assets/partner.png') gibi eklenebilir
  },
];

const GoalScreen = ({ navigation }) => {
  const [selected, setSelected] = useState(null);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.logoContainer}>
          <Image source={require('../../../assets/main_logo.png')} style={styles.logo} resizeMode="contain" />
        </View>
        <Text style={styles.title}>Hedefiniz ne?</Text>
        {goals.map((goal) => (
          <TouchableOpacity
            key={goal.id}
            style={[styles.goalCard, selected === goal.id && styles.goalCardSelected]}
            onPress={() => setSelected(goal.id)}
            activeOpacity={0.8}
          >
            <Text style={styles.goalText}>{goal.label}</Text>
            {/* Görsel eklemek isterseniz:
            {goal.image && <Image source={goal.image} style={styles.goalImage} />}
            */}
          </TouchableOpacity>
        ))}
        <TouchableOpacity
          style={[styles.nextBtn, selected && styles.nextBtnActive, !selected && styles.nextBtnDisabled]}
          disabled={!selected}
          onPress={() => {
            if (selected === 1) navigation.navigate('BirthYear');
            // Diğer hedefler için başka yönlendirme eklenebilir
          }}
        >
          <Text style={styles.nextBtnText}>İleri</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: SIZES.spacing.lg,
    paddingTop: 32,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  logo: {
    width: 100,
    height: 100,
  },
  title: {
    fontSize: SIZES['2xl'],
    fontWeight: 'bold',
    color: COLORS.text.primary,
    textAlign: 'center',
    marginBottom: SIZES.spacing['2xl'],
  },
  goalCard: {
    width: '100%',
    backgroundColor: COLORS.secondary,
    borderRadius: 32,
    paddingVertical: SIZES.spacing.xl,
    paddingHorizontal: SIZES.spacing.lg,
    marginBottom: SIZES.spacing.lg,
    alignItems: 'flex-start',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  goalCardSelected: {
    backgroundColor: '#E48CA0',
  },
  goalText: {
    fontSize: SIZES.base,
    color: COLORS.white,
  },
  nextBtn: {
    backgroundColor: COLORS.primary,
    borderRadius: 32,
    paddingVertical: SIZES.spacing.base,
    alignItems: 'center',
    marginTop: SIZES.spacing.xl,
    width: '100%',
  },
  nextBtnActive: {
    backgroundColor: '#E48CA0',
  },
  nextBtnDisabled: {
    backgroundColor: COLORS.gray[200],
  },
  nextBtnText: {
    color: COLORS.white,
    fontSize: SIZES.base,
  },
});

export default GoalScreen; 