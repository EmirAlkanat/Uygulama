import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Image, Keyboard, TouchableWithoutFeedback } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SIZES } from '../../constants';

const NicknameScreen = ({ navigation }) => {
  const [nickname, setNickname] = useState('');

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
      <SafeAreaView style={styles.safeArea}>
        <TouchableOpacity style={styles.skipBtn} onPress={() => {/* Atla fonksiyonu */}}>
          <Text style={styles.skipText}>Atla</Text>
        </TouchableOpacity>
        <View style={styles.container}>
          <View style={styles.logoContainer}>
            <Image source={require('../../../assets/main_logo.png')} style={styles.logo} resizeMode="contain" />
          </View>
          <Text style={styles.subtitle}>Birbirimizi daha yakından tanıyalım!</Text>
          <Text style={styles.title}>Adettim'in size nasıl hitap etmesini istersiniz?</Text>
          <TextInput
            style={styles.input}
            value={nickname}
            onChangeText={setNickname}
          />
        </View>
        <TouchableOpacity
          style={[styles.button, !nickname && styles.buttonDisabled]}
          disabled={!nickname}
          onPress={() => navigation.navigate('Welcome', { nickname })}
        >
          <Text style={styles.buttonText}>Devam et</Text>
        </TouchableOpacity>
      </SafeAreaView>
    </TouchableWithoutFeedback>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  skipBtn: {
    position: 'absolute',
    top: 16,
    right: 24,
    zIndex: 10,
  },
  skipText: {
    color: COLORS.gray[400],
    fontSize: SIZES.lg,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: SIZES.spacing.lg,
    marginTop: -60,
  },
  subtitle: {
    fontSize: SIZES.lg,
    color: COLORS.text.secondary,
    marginBottom: SIZES.spacing.base,
    textAlign: 'center',
  },
  title: {
    fontSize: SIZES['2xl'],
    fontWeight: 'bold',
    color: COLORS.text.primary,
    textAlign: 'center',
    marginBottom: SIZES.spacing.xl,
  },
  input: {
    width: '100%',
    height: 48,
    borderRadius: SIZES.radius.base,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.gray[200],
    paddingHorizontal: SIZES.spacing.base,
    fontSize: SIZES.base,
    color: COLORS.text.primary,
    marginBottom: SIZES.spacing['2xl'],
  },
  button: {
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radius.full,
    paddingVertical: SIZES.spacing.base,
    alignItems: 'center',
    marginHorizontal: SIZES.spacing.lg,
    marginBottom: SIZES.spacing.lg,
  },
  buttonDisabled: {
    backgroundColor: COLORS.secondary,
  },
  buttonText: {
    color: COLORS.white,
    fontSize: SIZES.base,
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 16,
  },
  logo: {
    width: 100,
    height: 100,
  },
});

export default NicknameScreen; 