import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { COLORS, SIZES } from '../../constants';

const WelcomeScreen = ({ route, navigation }) => {
  const { nickname } = route.params || {};

  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('UsageType');
    }, 2000);
    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <Image source={require('../../../assets/main_logo.png')} style={styles.logo} resizeMode="contain" />
        <Text style={styles.title}>
          Tanıştığımıza memnun oldum{nickname ? ',' : ''}
        </Text>
        {nickname ? (
          <Text style={styles.nickname}>{nickname}!</Text>
        ) : null}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: -120,
  },
  logo: {
    width: 120,
    height: 120,
    marginBottom: SIZES.spacing.xl,
  },
  title: {
    fontSize: SIZES['2xl'],
    fontWeight: 'bold',
    color: COLORS.text.primary,
    textAlign: 'center',
  },
  nickname: {
    fontSize: SIZES['2xl'],
    fontWeight: 'bold',
    color: COLORS.text.primary,
    textAlign: 'center',
    marginTop: 4,
  },
});

export default WelcomeScreen; 