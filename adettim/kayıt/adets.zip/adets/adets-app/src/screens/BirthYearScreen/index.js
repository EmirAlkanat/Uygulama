import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  NativeSyntheticEvent,
  NativeScrollEvent,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

const ITEM_HEIGHT = 60;
const YEARS = Array.from({ length: 2025 - 1970 + 1 }, (_, i) => 1970 + i); // 1970–2025

const BirthYearScreen = ({ navigation }) => {
  const [selectedYear, setSelectedYear] = useState(2006);
  const flatListRef = useRef(null);

  useEffect(() => {
    // İlk açılışta seçili yılı ortala
    const index = YEARS.indexOf(selectedYear);
    flatListRef.current?.scrollToIndex({
      index,
      viewPosition: 0.5,
      animated: false,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleScrollEnd = (e) => {
    const offsetY = e.nativeEvent.contentOffset.y;
    const index = Math.round((offsetY - ITEM_HEIGHT * 2) / ITEM_HEIGHT);
    const year = YEARS[index];
    if (year !== selectedYear) {
      setSelectedYear(year);
    }
  };

  const renderItem = ({ item }) => {
    const isSelected = item === selectedYear;
    return (
      <TouchableOpacity
        onPress={() => {
          const index = YEARS.indexOf(item);
          flatListRef.current?.scrollToIndex({
            index,
            viewPosition: 0.5,
            animated: true,
          });
          setSelectedYear(item);
        }}
        activeOpacity={0.8}
        style={styles.yearItem}
      >
        <View style={[styles.yearBox, isSelected && styles.yearBoxSelected]}>
          <Text style={[styles.yearText, isSelected && styles.yearTextSelected]}>
            {item}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <Text style={styles.title}>Doğum yılınız nedir?</Text>
      <Text style={styles.subtitle}>
        Yaşa bağlı hormon dalgalanmaları nedeniyle{' '}adet döngünüz yıllar içinde değişir
      </Text>
      <View style={styles.listContainer}>
        <View style={styles.highlight} pointerEvents="none" />
        <FlatList
          ref={flatListRef}
          data={YEARS}
          keyExtractor={(item) => item.toString()}
          renderItem={renderItem}
          showsVerticalScrollIndicator={false}
          getItemLayout={(_, index) => ({
            length: ITEM_HEIGHT,
            offset: ITEM_HEIGHT * index,
            index,
          })}
          contentContainerStyle={{
            paddingTop: ITEM_HEIGHT * 2,
            paddingBottom: ITEM_HEIGHT * 2,
          }}
          onMomentumScrollEnd={handleScrollEnd}
        />
      </View>
      <TouchableOpacity
        style={styles.nextButton}
        onPress={() => {
          console.log('Seçilen yıl:', selectedYear);
          // navigation.navigate('NextScreen', { birthYear: selectedYear });
        }}
      >
        <Text style={styles.nextButtonText}>Sonraki Adım</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0F0F2D',
    paddingHorizontal: 24,
    paddingTop: 32,
  },
  title: {
    fontSize: 24,
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
  },
  subtitle: {
    fontSize: 14,
    color: '#BBBBBB',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  listContainer: {
    height: ITEM_HEIGHT * 5, // 5 yıl yüksekliği
    position: 'relative',
    overflow: 'hidden',
  },
  yearItem: {
    height: ITEM_HEIGHT,
    justifyContent: 'center',
    alignItems: 'center',
  },
  yearBox: {
    height: ITEM_HEIGHT,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 12,
    width: '100%',
  },
  yearBoxSelected: {
    backgroundColor: '#2C2C4A',
    borderRadius: 16,
  },
  yearText: {
    fontSize: 24,
    color: '#888',
    fontWeight: '600',
  },
  yearTextSelected: {
    color: '#FF2D74',
    fontWeight: 'bold',
    fontSize: 26,
  },
  highlight: {
    position: 'absolute',
    top: '50%',
    height: ITEM_HEIGHT,
    width: '100%',
    backgroundColor: '#2C2C4A',
    transform: [{ translateY: -ITEM_HEIGHT / 2 }],
    borderRadius: 16,
    zIndex: -1,
  },
  nextButton: {
    backgroundColor: '#FF2D74',
    borderRadius: 32,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 32,
    marginTop: 12,
    shadowColor: '#FF2D74',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 8,
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default BirthYearScreen;
