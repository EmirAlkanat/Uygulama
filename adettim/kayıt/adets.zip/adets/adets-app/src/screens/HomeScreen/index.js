import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { globalStyles } from '../../styles/globalStyles';
import { COLORS, SIZES } from '../../constants';

const HomeScreen = () => {
  return (
    <SafeAreaView style={globalStyles.safeArea}>
      <View style={globalStyles.container}>
        <View style={styles.header}>
          <Text style={globalStyles.textTitle}>Adet Takip</Text>
          <Text style={globalStyles.textSmall}>Hoş geldiniz!</Text>
        </View>
        
        <View style={styles.content}>
          <Text style={globalStyles.text}>Ana sayfa içeriği buraya gelecek</Text>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  header: {
    padding: SIZES.spacing.lg,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  
  content: {
    flex: 1,
    padding: SIZES.spacing.lg,
    ...globalStyles.center,
  },
});

export default HomeScreen; 