import { StyleSheet } from 'react-native';
import { COLORS, SIZES } from '../constants';

export const globalStyles = StyleSheet.create({
  // Container stilleri
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  
  // Metin stilleri
  text: {
    color: COLORS.text.primary,
    fontSize: SIZES.base,
  },
  
  textSmall: {
    color: COLORS.text.secondary,
    fontSize: SIZES.sm,
  },
  
  textLarge: {
    color: COLORS.text.primary,
    fontSize: SIZES.lg,
    fontWeight: '600',
  },
  
  textTitle: {
    color: COLORS.text.primary,
    fontSize: SIZES['2xl'],
    fontWeight: 'bold',
  },
  
  // Buton stilleri
  button: {
    backgroundColor: COLORS.primary,
    paddingVertical: SIZES.spacing.base,
    paddingHorizontal: SIZES.spacing.lg,
    borderRadius: SIZES.radius.base,
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  buttonText: {
    color: COLORS.white,
    fontSize: SIZES.base,
  },
  
  buttonSecondary: {
    backgroundColor: COLORS.gray[100],
    paddingVertical: SIZES.spacing.base,
    paddingHorizontal: SIZES.spacing.lg,
    borderRadius: SIZES.radius.base,
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  buttonSecondaryText: {
    color: COLORS.text.primary,
    fontSize: SIZES.base,
  },
  
  // Kart stilleri
  card: {
    backgroundColor: COLORS.card,
    borderRadius: SIZES.radius.lg,
    padding: SIZES.spacing.lg,
    marginVertical: SIZES.spacing.sm,
    ...SIZES.shadow.base,
  },
  
  // Input stilleri
  input: {
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: SIZES.radius.base,
    paddingHorizontal: SIZES.spacing.base,
    paddingVertical: SIZES.spacing.sm,
    fontSize: SIZES.base,
    color: COLORS.text.primary,
  },
  
  // Boşluk stilleri
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  
  center: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  spaceBetween: {
    justifyContent: 'space-between',
  },
  
  spaceAround: {
    justifyContent: 'space-around',
  },
});

export default globalStyles; 