import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { globalStyles } from '../../styles/globalStyles';
import { COLORS, SIZES } from '../../constants';

const Button = ({ 
  title, 
  onPress, 
  variant = 'primary', 
  size = 'medium',
  disabled = false,
  style,
  textStyle,
  ...props 
}) => {
  const getButtonStyle = () => {
    const baseStyle = [globalStyles.button, styles.button];
    
    if (variant === 'secondary') {
      baseStyle[0] = globalStyles.buttonSecondary;
    }
    
    if (size === 'small') {
      baseStyle.push(styles.buttonSmall);
    } else if (size === 'large') {
      baseStyle.push(styles.buttonLarge);
    }
    
    if (disabled) {
      baseStyle.push(styles.buttonDisabled);
    }
    
    if (style) {
      baseStyle.push(style);
    }
    
    return baseStyle;
  };
  
  const getTextStyle = () => {
    const baseStyle = [globalStyles.buttonText];
    if (variant === 'secondary') {
      baseStyle[0] = globalStyles.buttonSecondaryText;
    }
    if (disabled) {
      baseStyle.push(styles.textDisabled);
    }
    if (textStyle) {
      baseStyle.push(textStyle);
    }
    return baseStyle;
  };
  
  return (
    <TouchableOpacity
      style={getButtonStyle()}
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.8}
      {...props}
    >
      <Text style={getTextStyle()}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    minHeight: 44,
  },
  
  buttonSmall: {
    paddingVertical: SIZES.spacing.sm,
    paddingHorizontal: SIZES.spacing.base,
    minHeight: 36,
  },
  
  buttonLarge: {
    paddingVertical: SIZES.spacing.lg,
    paddingHorizontal: SIZES.spacing.xl,
    minHeight: 52,
  },
  
  buttonDisabled: {
    backgroundColor: COLORS.gray[300],
    opacity: 0.6,
  },
  
  textDisabled: {
    color: COLORS.text.disabled,
    fontWeight: undefined,
  },
});

export default Button; 