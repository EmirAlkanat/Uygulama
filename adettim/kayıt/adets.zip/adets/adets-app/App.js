import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import PrivacyScreen from './src/screens/PrivacyScreen';
import NicknameScreen from './src/screens/NicknameScreen';
import WelcomeScreen from './src/screens/WelcomeScreen';
import UsageTypeScreen from './src/screens/UsageTypeScreen';
import GoalScreen from './src/screens/GoalScreen';
import BirthYearScreen from './src/screens/BirthYearScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <StatusBar style="auto" />
        <Stack.Navigator
          initialRouteName="Privacy"
          screenOptions={{ headerShown: false }}
        >
          <Stack.Screen name="Privacy" component={PrivacyScreen} />
          <Stack.Screen name="Nickname" component={NicknameScreen} />
          <Stack.Screen name="Welcome" component={WelcomeScreen} />
          <Stack.Screen name="UsageType" component={UsageTypeScreen} />
          <Stack.Screen name="Goal" component={GoalScreen} />
          <Stack.Screen name="BirthYear" component={BirthYearScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
